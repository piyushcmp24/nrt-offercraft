import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-campaign',
  templateUrl: './list-campaign.component.html',
  styleUrl: './list-campaign.component.scss'
})
export class ListCampaignComponent implements OnInit {

  constructor(){}
  ngOnInit(): void {
    console.log("campaign lists page")
  }


}
