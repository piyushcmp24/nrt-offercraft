// shared/components/index.ts
export { CapitalizePipe } from './capitalize.pipe';
