// shared/components/index.ts
export { AutoFocusDirective } from './auto-focus.directive';
