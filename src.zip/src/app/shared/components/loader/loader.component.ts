import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { LoaderService } from '../../../core/services/loader.service';

@Component({
  selector: 'app-loader',
  standalone: true,
  imports: [CommonModule, MatProgressBarModule],
  template: '<mat-progress-bar *ngIf="loader.isLoading$ | async" mode="indeterminate"></mat-progress-bar>'
})
export class LoaderComponent {
  constructor(public loader: LoaderService) {}
}