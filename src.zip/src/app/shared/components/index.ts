// shared/components/index.ts
export { AccordionComponent } from './accordion/accordion.component';
export { ModalComponent } from './modal/modal.component';
export { HeaderComponent } from './header/header.component';
export { FooterComponent } from './footer/footer.component';
export { SidebarComponent } from './sidebar/sidebar.component';
