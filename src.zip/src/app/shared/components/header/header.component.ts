import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  navLinks = [
    { path: '/', label: 'OVERVIEW' },
    { path: '/campaigns', label: 'CAMPAIGNS' },
    { path: '/rewards', label: 'REWARDS' },
    { path: '/instant-rewards', label: 'INSTANT REWARDS' },
    { path: '/questions', label: 'QUESTIONS' },
    { path: '/lobbies', label: 'LOBBIES' },
    { path: '/snapshots', label: 'SNAPSHOTS' },
    { path: '/reports', label: 'REPORTS' },
    { path: '/player-management', label: 'PLAYER MANAGEMENT' },
    { path: '/admin', label: 'ADMIN' }
  ];
}
