import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { AccordionComponent, ModalComponent, HeaderComponent, FooterComponent } from './components';
import { AutoFocusDirective } from './directives';
import { CapitalizePipe } from './pipes';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { MatIconModule } from '@angular/material/icon';

// import { HeaderComponent } from './components/header/header.component';
// import { FooterComponent } from './components/footer/footer.component';

@NgModule({
  declarations: [HeaderComponent, FooterComponent, AccordionComponent, ModalComponent, AutoFocusDirective, CapitalizePipe, SidebarComponent],
  imports: [CommonModule, RouterModule, MatButtonModule, MatIconModule],
  exports: [HeaderComponent, FooterComponent, AccordionComponent, ModalComponent, AutoFocusDirective, CapitalizePipe, SidebarComponent, MatIconModule]
})
export class SharedModule { }
