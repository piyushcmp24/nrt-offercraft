import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, delay, of, tap } from 'rxjs';
import { User } from './models/user.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private userSubject = new BehaviorSubject<User | null>(null);
  user$ = this.userSubject.asObservable();

  constructor(private http: HttpClient, private router: Router) {
    const user = localStorage.getItem('user');
    if (user) {
      this.userSubject.next(JSON.parse(user));
    }
  }

  // login(username: string, password: string) {
  //   return this.http.post<User>('/api/login', { username, password }).pipe(
  //     tap(user => {
  //       console.log("user: ", user);
        
  //       localStorage.setItem('user', JSON.stringify(user));
  //       this.userSubject.next(user);
  //     })
  //   );
  // }

  login(email: string, password: string) {
    return of(
      {
        email, 
        role: email === 'admin@example.com' ? 'admin' : 'user', 
        token: 'dummy-token' 
      })
      .pipe(
      delay(500),
      tap((user:any) => {
        // console.log("new user: ", user);
        
        if ((email === 'admin@example.com' && password === 'admin') || (email === 'user@example.com' && password === 'user')) {
          localStorage.setItem('user', JSON.stringify(user));
          this.userSubject.next(user);
        } else {
          throw new Error('Invalid credentials');
        }
      })
    );
  }

  logout() {
    localStorage.removeItem('user');
    localStorage.removeItem('role');
    localStorage.removeItem('token');
    this.userSubject.next(null);
    this.router.navigate(['/login']);
  }

  get currentUser(): User | null {
    return this.userSubject.value;
  }

  // hasRole(role: 'admin' | 'user'): boolean {
  //   return this.currentUser?.role === role;
  // }

  getToken(): string | null {
    return this.currentUser?.token || null;
  }

  requestPasswordReset(email: string) {
    return this.http.post('/api/auth/forgot-password', { email });
  }
}
