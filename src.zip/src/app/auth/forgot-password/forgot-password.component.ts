import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from './../../auth/auth.service';
import { ForgotPasswordService } from '../../core/service/forgot-password.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrl: 'forgot-password.component.scss'
})
export class ForgotPasswordComponent {
  form: FormGroup;
  message: string = '';
  error: string = '';

  constructor(private fb: FormBuilder, private authService: AuthService, 
    private forgotService: ForgotPasswordService) {
    this.form = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
    });
  }

  onSubmit() {
    if (this.form.valid) {
      const email = this.form.value.email;

      this.forgotService.sendForgotPasswordEmail(email).subscribe({
        
        next: () => { console.log(email); this.message = 'Instructions sent!'; },
        error: () => { this.error = 'Error sending email.'; }
      });

      // this.authService.requestPasswordReset(email).subscribe({
      //   next: () => {
      //     this.message = 'Reset link sent. Check your email.';
      //     this.error = '';
      //   },
      //   error: (err) => {
      //     this.error = 'Error sending reset link.';
      //     this.message = '';
      //   }
      // });
    }
  }
}
